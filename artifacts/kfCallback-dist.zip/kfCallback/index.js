"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// rewrite/cloud/src/functions/cs/kfCallback/index.ts
var index_exports = {};
__export(index_exports, {
  main: () => main
});
module.exports = __toCommonJS(index_exports);

// rewrite/shared/src/status.ts
function statesOf(spec) {
  const set = /* @__PURE__ */ new Set([...spec.initial, ...spec.terminal]);
  for (const t of spec.transitions) {
    for (const f of t.from) set.add(f);
    set.add(t.to);
  }
  return [...set].sort();
}

// rewrite/shared/src/order.ts
var ORDER_STATUS_SPEC = {
  collection: "orders",
  /** 初始态：createOrder 写入（real→pending 等回调 / mock→paid 直付）。 */
  initial: ["pending", "paid"],
  /** 终态。refund_required=钱已收但缺货、待人工退款；payment_exception=到账金额不符、待人工处理。 */
  terminal: ["done", "closed", "refund_required", "payment_exception"],
  transitions: [
    { from: ["pending"], to: "paid", trigger: "pay/payCallback\uFF080\u5143\u5355/\u652F\u4ED8\u6210\u529F\xB7\u5E93\u5B58\u81EA\u4E0B\u5355\u6301\u6709\uFF09" },
    { from: ["pending"], to: "closed", trigger: "pay \u60F0\u6027\u5173\u5355 / closeExpiredOrders \u5B9A\u65F6\u5173\u5355" },
    { from: ["closed"], to: "paid", trigger: "payCallback\uFF08\u5173\u5355\u540E\u94B1\u5230\u8D26\xB7\u91CD\u62A2\u5E93\u5B58\u6210\u529F\u624D\u590D\u6D3B\uFF09" },
    { from: ["closed"], to: "refund_required", trigger: "payCallback\uFF08\u5173\u5355\u56DE\u8865\u540E\u665A\u5230\u56DE\u8C03\xB7\u5E93\u5B58\u5DF2\u88AB\u4E70\u8D70\xB7\u94B1\u5DF2\u6536\u5F85\u4EBA\u5DE5\u9000\u6B3E\uFF09" },
    { from: ["pending"], to: "payment_exception", trigger: "payCallback\uFF08\u5230\u8D26\u91D1\u989D\u4E0D\u7B26\xB7\u5F85\u4EBA\u5DE5\u6838\u5BF9\uFF09" },
    { from: ["closed"], to: "payment_exception", trigger: "payCallback\uFF08\u5173\u5355\u540E\u5230\u8D26\u91D1\u989D\u4E0D\u7B26\xB7\u5F85\u4EBA\u5DE5\u6838\u5BF9\uFF09" },
    { from: ["paid", "shipped"], to: "shipped", trigger: "adminApi.shipOrder\uFF08\u9996\u53D1/\u6539\u5355\u53F7\xB7\u5E42\u7B49\uFF09" },
    { from: ["shipped"], to: "done", trigger: "confirmReceive\uFF08\u786E\u8BA4\u6536\u8D27\uFF09" }
  ]
};
var AFTERSALE_STATUS_SPEC = {
  collection: "afterSales",
  initial: ["applied"],
  terminal: ["refunded", "rejected"],
  transitions: [
    { from: ["applied"], to: "approved", trigger: "adminApi.approveRefund\uFF08\u539F\u5B50\u62A2\u5360\xB7\u89E6\u53D1\u9000\u6B3E\u5DE5\u4F5C\u6D41\uFF09" },
    { from: ["approved"], to: "applied", trigger: "adminApi.approveRefund \u56DE\u6EDA\uFF08\u5DE5\u4F5C\u6D41\u672A\u53D7\u7406\xB7\u6761\u4EF6\u5316\uFF0C\u4E0D\u6253\u56DE\u5DF2\u9000\u6B3E\uFF09" },
    { from: ["applied"], to: "rejected", trigger: "adminApi.rejectRefund\uFF08\u62D2\u7EDD\u552E\u540E\uFF09" },
    { from: ["applied", "approved"], to: "refunded", trigger: "refundCallback\uFF08\u9000\u6B3E\u6210\u529F\u5E42\u7B49\uFF09" }
  ]
};
var dictOf = (states) => Object.fromEntries(states.map((s) => [s.toUpperCase(), s]));
var ORDER_STATUS = dictOf(statesOf(ORDER_STATUS_SPEC));
var AFTERSALE_STATUS = dictOf(statesOf(AFTERSALE_STATUS_SPEC));

// rewrite/shared/src/collections.ts
var COLLECTIONS = {
  users: "users",
  orders: "orders",
  afterSales: "afterSales",
  products: "products",
  productsDraft: "productsDraft",
  courses: "courses",
  coursesDraft: "coursesDraft",
  activations: "activations",
  qrcodes: "qrcodes",
  progress: "progress",
  reviews: "reviews",
  content: "content",
  config: "config",
  adminConfig: "adminConfig",
  cards: "cards",
  uploadChunks: "uploadChunks",
  events: "events",
  rateLimit: "rateLimit",
  inventory: "inventory",
  auditLog: "auditLog",
  kfState: "kfState",
  kfIdentity: "kfIdentity",
  feedback: "feedback",
  wxBills: "wxBills",
  checkpoints: "checkpoints",
  conversations: "conversations",
  kb: "kb",
  csat: "csat",
  csSession: "csSession",
  agentState: "agentState",
  materials: "materials",
  suppliers: "suppliers",
  purchaseOrders: "purchaseOrders",
  outworkOrders: "outworkOrders",
  assemblyOrders: "assemblyOrders",
  stockLedger: "stockLedger",
  bomProfiles: "bomProfiles",
  // 观测
  anomalies: "anomalies",
  // bug 收集器账本（防治静默 bug·指纹去重·仅管理端·recordAnomaly 单口写入）
  inspectRuns: "inspectRuns",
  // 巡检机体检报告（每次运行 A/B 检查红绿灯·仅管理端·runInspection 单口写入）
  // 敏感凭证入库单源（2026-07-12 决策·config-checklist 本页填写自动生效）：doc('wxkf')/doc('wxpay')，
  // 云函数运行时读库优先、env 兜底迁移期——见 kit/secureConfig.ts。仅 saveSecureConfig 单口写入。
  secureConfig: "secureConfig",
  // createOrder 幂等键（防网络超时重试双建单）：_id=(openid+客户端幂等键) 确定性哈希，
  // 存 { openid, orderId, createdAt }；建单前 claim、建单后回填 orderId——见 orders.ts createOrder。
  orderIdempotency: "orderIdempotency",
  // 反馈通知游标（意见箱铃铛）：doc('state') 记录上次扫描时间, 防重复推送
  feedbackNotifyCursor: "feedbackNotifyCursor"
};

// rewrite/shared/src/limits.ts
var PAY_WINDOW_MS = 15 * 60 * 1e3;

// rewrite/shared/src/seed/course.ts
var parseDur = (s) => {
  const [m, sec] = String(s).split(":").map(Number);
  return m * 60 + sec;
};
var mmss = (t) => {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
};
var SEG_STEPS = ["\u5148\u770B\u6210\u54C1\u957F\u5565\u6837", "\u8FD9\u4E2A\u73A9\u5076\u662F\u4EC0\u4E48", "\u9700\u8981\u7684\u6750\u6599\u5DE5\u5177", "\u5173\u952E\u9488\u6CD5\u6162\u52A8\u4F5C", "\u6536\u5C3E\u4E0E\u81EA\u68C0"];
function buildSegments(lessonId, dur) {
  const total = parseDur(dur);
  const n = SEG_STEPS.length;
  const base2 = Math.floor(total / n);
  return SEG_STEPS.map((name, i) => ({
    id: `${lessonId}-s${i + 1}`,
    name,
    dur: mmss(i === n - 1 ? total - base2 * (n - 1) : base2),
    videoFileId: null
  }));
}
var CHAPTERS = [
  {
    id: "c1",
    title: "\u5F00\u59CB\u4E4B\u524D \xB7 \u5907\u597D\u5DE5\u5177\u548C\u5FC3\u60C5",
    lessons: [
      { id: "l1", name: "\u8BA4\u8BC6\u4F60\u7684\u94A9\u7EC7\u5DE5\u5177\u5305", dur: "03:20" },
      { id: "l2", name: "\u6BDB\u7EBF\u4E0E\u94A9\u9488\u600E\u4E48\u6311\u9009", dur: "04:05" },
      { id: "l3", name: "\u770B\u61C2\u56FE\u89E3\u91CC\u7684\u7B26\u53F7", dur: "05:12" },
      { id: "l4", name: "\u8D77\u624B \xB7 \u94A9\u4E00\u4E2A\u9B54\u672F\u73AF", dur: "06:40" }
    ]
  },
  {
    id: "c2",
    title: "\u57FA\u7840\u9488\u6CD5 \xB7 \u4E00\u770B\u5C31\u4F1A",
    lessons: [
      { id: "l5", name: "\u9501\u9488\uFF1A\u6240\u6709\u82B1\u6837\u7684\u5730\u57FA", dur: "04:48" },
      { id: "l6", name: "\u77ED\u9488\uFF1A\u94A9\u51FA\u5706\u6EDA\u6EDA\u7684\u8EAB\u4F53", dur: "07:10" },
      { id: "l7", name: "\u52A0\u9488\u4E0E\u51CF\u9488\u7684\u5C0F\u79D8\u5BC6", dur: "06:25" },
      { id: "l8", name: "\u6536\u5C3E\u85CF\u7EBF\uFF0C\u770B\u4E0D\u51FA\u9488\u811A", dur: "05:30" }
    ]
  },
  {
    id: "c3",
    title: "\u94A9\u51FA\u5C0F\u9E2D\u7684\u8EAB\u4F53",
    lessons: [
      { id: "l9", name: "\u4ECE\u9E2D\u5934\u5F00\u59CB\uFF0C\u4E00\u5708\u4E00\u5708", dur: "08:15" },
      { id: "l10", name: "\u9E2D\u8EAB\u4E0E\u9E2D\u5C3E\u7684\u8FC7\u6E21", dur: "07:40" },
      { id: "l11", name: "\u94A9\u4E00\u5BF9\u5C0F\u7FC5\u8180", dur: "05:55" },
      { id: "l12", name: "\u585E\u68C9\u82B1\u7684\u529B\u9053\u4E0E\u624B\u611F", dur: "04:20" }
    ]
  },
  {
    id: "c4",
    title: "\u7EC4\u88C5 \xB7 \u7ED9\u5C0F\u9E2D\u4E00\u4E2A\u8868\u60C5",
    lessons: [
      { id: "l13", name: "\u7F1D\u4E0A\u9E2D\u5599\u4E0E\u5C0F\u811A", dur: "06:05" },
      { id: "l14", name: "\u5B9A\u4F4D\u773C\u775B\uFF0C\u795E\u6001\u5168\u9760\u5B83", dur: "05:18" },
      { id: "l15", name: "\u7CFB\u4E0A\u5E78\u8FD0\u5C0F\u56F4\u5DFE", dur: "04:02" },
      { id: "l16", name: "\u5B8C\u6210 \xB7 \u62CD\u5F20\u7167\u6652\u6652\u4F60\u7684\u9E2D", dur: "03:36" }
    ]
  }
];
var SEED_COURSES = [
  {
    id: "course-duck",
    title: "\u96F6\u57FA\u7840 \xB7 \u94A9\u7EC7\u4F60\u7684\u7B2C\u4E00\u53EA\u5C0F\u68C9\u9E2D",
    sort: 0,
    chapters: CHAPTERS.map((c) => ({
      id: c.id,
      title: c.title,
      lessons: c.lessons.map((l) => ({
        id: l.id,
        name: l.name,
        dur: l.dur,
        segments: buildSegments(l.id, l.dur)
      }))
    }))
  }
];

// rewrite/cloud/src/kit/db.ts
var import_wx_server_sdk = __toESM(require("wx-server-sdk"), 1);
var inited = false;
function getDb() {
  if (!inited) {
    import_wx_server_sdk.default.init({ env: import_wx_server_sdk.default.DYNAMIC_CURRENT_ENV });
    inited = true;
  }
  return import_wx_server_sdk.default.database();
}

// rewrite/cloud/src/kit/gate.ts
var import_wx_server_sdk2 = __toESM(require("wx-server-sdk"), 1);

// rewrite/cloud/src/kit/transition.ts
async function transition(coll, id, from, to, patch) {
  const db2 = getDb();
  const got = await db2.collection(coll).doc(id).get().catch(() => null);
  if (!got || !got.data) return { moved: false };
  const doc = got.data;
  if (!from.includes(doc.status)) return { moved: false, doc };
  const extra = typeof patch === "function" ? patch(doc) : patch || {};
  const _ = db2.command;
  const r = await db2.collection(coll).where({ _id: id, status: _.in([...from]) }).update({ data: { status: to, ...extra } });
  return { moved: r.stats.updated === 1, doc };
}

// rewrite/cloud/src/kit/observe.ts
var MARK = "[LD_ALERT]";
function alert(sev, fn, code, ctx = {}) {
  try {
    console.error(`${MARK} sev=${sev} fn=${fn} code=${code} ctx=${JSON.stringify(ctx)}`);
  } catch {
  }
}

// rewrite/cloud/src/kit/storage.ts
var import_wx_server_sdk3 = __toESM(require("wx-server-sdk"), 1);
var CACHE_MARGIN_MS = 5 * 60 * 1e3;

// rewrite/cloud/src/kit/flow.ts
var import_wx_server_sdk4 = __toESM(require("wx-server-sdk"), 1);

// rewrite/cloud/src/kit/wecom.ts
var import_crypto = __toESM(require("crypto"), 1);
var import_https = __toESM(require("https"), 1);

// rewrite/cloud/src/kit/secureConfig.ts
var ENV_FALLBACK = {
  "wxkf.corpId": "WXKF_CORPID",
  "wxkf.secret": "WXKF_SECRET",
  "wxkf.token": "WXKF_TOKEN",
  "wxkf.aesKey": "WXKF_AESKEY",
  "wxkf.agentId": "WXKF_AGENTID",
  "wxkf.miniappAppId": "WXKF_MINIAPP_APPID",
  "wxkf.thumbMediaId": "WXKF_THUMB_MEDIA_ID",
  "wxpay.mchPrivateKey": "WXPAY_MCH_PRIVATE_KEY",
  "wxpay.mchSerial": "WXPAY_MCH_SERIAL"
};
async function getSecureConfig(db2, docId, field) {
  const got = await db2.collection(COLLECTIONS.secureConfig).doc(docId).get().catch(() => null);
  const v = got && got.data && got.data[field];
  if (typeof v === "string" && v) return v;
  const envKey = ENV_FALLBACK[`${docId}.${field}`];
  return envKey ? process.env[envKey] || "" : "";
}
async function getSecureConfigFields(db2, docId, fields) {
  const got = await db2.collection(COLLECTIONS.secureConfig).doc(docId).get().catch(() => null);
  const data = got && got.data || {};
  const out = {};
  for (const f of fields) {
    const v = data[f];
    out[f] = typeof v === "string" && v ? v : process.env[ENV_FALLBACK[`${docId}.${f}`]] || "";
  }
  return out;
}

// rewrite/cloud/src/kit/wecom.ts
var QY = "https://qyapi.weixin.qq.com/cgi-bin";
var httpsFetch = (url, init) => new Promise((resolve, reject) => {
  const u = new URL(url);
  const req = import_https.default.request(
    { method: init?.method || "GET", hostname: u.hostname, path: u.pathname + u.search, headers: init?.headers },
    (res) => {
      let body = "";
      res.on("data", (c) => body += c);
      res.on("end", () => resolve({ json: async () => JSON.parse(body || "{}") }));
    }
  );
  req.on("error", reject);
  if (init?.body) req.write(init.body);
  req.end();
});
var defaultFetch = (url, init) => typeof globalThis.fetch === "function" ? globalThis.fetch(url, init) : httpsFetch(url, init);
function kfSignature(token, timestamp, nonce, encrypt) {
  const arr = [token, timestamp, nonce, encrypt].sort();
  return import_crypto.default.createHash("sha1").update(arr.join("")).digest("hex");
}
function verifyKfSignature(token, timestamp, nonce, encrypt, signature) {
  const expect = kfSignature(token, timestamp, nonce, encrypt);
  const a = Buffer.from(expect);
  const b = Buffer.from(String(signature || ""));
  return a.length === b.length && import_crypto.default.timingSafeEqual(a, b);
}
function aesKeyOf(encodingAESKey) {
  return Buffer.from(encodingAESKey + "=", "base64");
}
function decryptKfMessage(encodingAESKey, encrypted) {
  const key = aesKeyOf(encodingAESKey);
  const iv = key.subarray(0, 16);
  const decipher = import_crypto.default.createDecipheriv("aes-256-cbc", key, iv);
  decipher.setAutoPadding(false);
  const buf = Buffer.concat([decipher.update(Buffer.from(encrypted, "base64")), decipher.final()]);
  const pad = buf[buf.length - 1];
  if (!(pad >= 1 && pad <= 32) || pad > buf.length) throw new Error("BAD_PADDING");
  const data = buf.subarray(16, buf.length - pad);
  if (data.length < 4) throw new Error("BAD_PLAINTEXT");
  const msgLen = data.readUInt32BE(0);
  if (msgLen < 0 || 4 + msgLen > data.length) throw new Error("BAD_MSGLEN");
  const message = data.subarray(4, 4 + msgLen).toString("utf8");
  const receiveId = data.subarray(4 + msgLen).toString("utf8");
  return { message, receiveId };
}
function xmlTag(xml, tag) {
  const m = xml.match(new RegExp(`<${tag}>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${tag}>`));
  return m ? m[1] : "";
}
var httpReply = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "text/plain" },
  body
});
function readQuery(event) {
  return event.queryStringParameters || event.queryString || event.query || {};
}
function readBody(event) {
  const raw = event.isBase64Encoded ? Buffer.from(event.body || "", "base64").toString() : event.body;
  return raw || "";
}
function defineKfCallback(opts) {
  return async (event) => {
    const { token, aesKey, corpid } = await opts.creds();
    const receiveIdOk = (receiveId) => !corpid || receiveId === corpid;
    const q = readQuery(event);
    const method = String(event.httpMethod || "POST").toUpperCase();
    if (method === "GET") {
      const { msg_signature: msg_signature2, timestamp: timestamp2, nonce: nonce2, echostr } = q;
      if (!token || !aesKey || !verifyKfSignature(token, timestamp2, nonce2, echostr, msg_signature2)) {
        return httpReply(200, "");
      }
      try {
        const dec2 = decryptKfMessage(aesKey, echostr);
        if (!receiveIdOk(dec2.receiveId)) return httpReply(200, "");
        return httpReply(200, dec2.message);
      } catch {
        return httpReply(200, "");
      }
    }
    const body = readBody(event);
    const encrypt = xmlTag(body, "Encrypt");
    const { msg_signature, timestamp, nonce } = q;
    if (!token || !aesKey || !encrypt || !verifyKfSignature(token, timestamp, nonce, encrypt, msg_signature)) {
      alert("security", "kfCallback", "FORGED_CALLBACK", {});
      return httpReply(200, "");
    }
    let dec;
    try {
      dec = decryptKfMessage(aesKey, encrypt);
    } catch {
      alert("security", "kfCallback", "DECRYPT_FAILED", {});
      return httpReply(200, "");
    }
    if (!receiveIdOk(dec.receiveId)) {
      alert("security", "kfCallback", "RECEIVEID_MISMATCH", {});
      return httpReply(200, "");
    }
    const xml = dec.message;
    await opts.onEvent({ syncToken: xmlTag(xml, "Token"), openKfId: xmlTag(xml, "OpenKfId"), raw: xml });
    return httpReply(200, "");
  };
}
var TOKEN_ID = "token";
var TOKEN_SKEW_MS = 5 * 6e4;
async function getAccessToken(cfg, fetchImpl = defaultFetch) {
  const db2 = getDb();
  const now = Date.now();
  const got = await db2.collection(COLLECTIONS.kfState).doc(TOKEN_ID).get().catch(() => null);
  const rec = got && got.data ? got.data : null;
  if (rec && typeof rec.expireAt === "number" && rec.expireAt - TOKEN_SKEW_MS > now && rec.accessToken) {
    return rec.accessToken;
  }
  let r;
  try {
    r = await fetchImpl(`${QY}/gettoken?corpid=${encodeURIComponent(cfg.corpid)}&corpsecret=${encodeURIComponent(cfg.secret)}`);
  } catch {
    alert("security", "wecom", "GETTOKEN_FETCH_FAIL", {});
    throw new Error("GETTOKEN_FETCH_FAIL");
  }
  const j = await r.json();
  if (j.errcode || !j.access_token) {
    alert("security", "wecom", "GETTOKEN_FAILED", { errcode: j.errcode });
    throw new Error("GETTOKEN_FAILED:" + j.errcode);
  }
  const expireAt = now + (Number(j.expires_in) || 7200) * 1e3;
  await db2.collection(COLLECTIONS.kfState).doc(TOKEN_ID).set({ data: { accessToken: j.access_token, expireAt, updatedAt: now } }).catch(() => {
  });
  return j.access_token;
}
async function getCachedKfToken(db2) {
  const now = Date.now();
  const got = await db2.collection(COLLECTIONS.kfState).doc(TOKEN_ID).get().catch(() => null);
  const rec = got && got.data ? got.data : null;
  if (rec && typeof rec.expireAt === "number" && rec.expireAt - TOKEN_SKEW_MS > now && rec.accessToken) return rec.accessToken;
  return "";
}
async function post(path, accessToken, payload, fetchImpl) {
  const r = await fetchImpl(`${QY}/${path}?access_token=${encodeURIComponent(accessToken)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  return r.json();
}
async function syncMsg(accessToken, args, fetchImpl = defaultFetch) {
  const j = await post(
    "kf/sync_msg",
    accessToken,
    { cursor: args.cursor || "", token: args.token, limit: args.limit || 1e3, open_kfid: args.openKfId },
    fetchImpl
  );
  return { next_cursor: j.next_cursor || "", has_more: Number(j.has_more) || 0, msg_list: j.msg_list || [], errcode: j.errcode };
}
async function sendMsg(accessToken, payload, fetchImpl = defaultFetch) {
  return post("kf/send_msg", accessToken, payload, fetchImpl);
}
var AGENT_DESK_URL = process.env.WXKF_AGENT_URL || "https://www.luckyducky.cn/agent/";
async function sendAppMessage(accessToken, args, fetchImpl = defaultFetch) {
  return post(
    "message/send",
    accessToken,
    {
      touser: (args.touser || []).join("|"),
      msgtype: "textcard",
      agentid: args.agentid,
      textcard: {
        title: args.textcard.title,
        description: args.textcard.description,
        url: args.textcard.url,
        btntxt: args.textcard.btntxt || "\u63A5\u5F85"
      }
    },
    fetchImpl
  );
}
async function sendAgentCard(db2, touser, card, fetchImpl = defaultFetch) {
  try {
    const to = (touser || []).filter(Boolean);
    if (!to.length) return;
    const agentid = await getSecureConfig(db2, "wxkf", "agentId");
    if (!agentid) return;
    const token = await getCachedKfToken(db2);
    if (!token) return;
    await sendAppMessage(token, { agentid, touser: to, textcard: card }, fetchImpl);
  } catch {
  }
}
async function getServiceState(accessToken, args, fetchImpl = defaultFetch) {
  const j = await post("kf/service_state/get", accessToken, { open_kfid: args.openKfId, external_userid: args.externalUserId }, fetchImpl);
  if (j.errcode) {
    alert("security", "wecom", "SERVICE_STATE_GET_FAILED", { errcode: j.errcode });
    return -1;
  }
  return typeof j.service_state === "number" ? j.service_state : -1;
}
async function enterSmartAssistant(accessToken, args, fetchImpl = defaultFetch) {
  return post(
    "kf/service_state/trans",
    accessToken,
    { open_kfid: args.openKfId, external_userid: args.externalUserId, service_state: 1 },
    fetchImpl
  );
}
async function ensureSmartAssistant(accessToken, args, fetchImpl = defaultFetch) {
  const state = await getServiceState(accessToken, args, fetchImpl);
  if (state === 1) return "proceed";
  if (state !== 0 && state !== -1) return "skip";
  const r = await enterSmartAssistant(accessToken, args, fetchImpl);
  if (r && r.errcode) {
    alert("security", "wecom", "ENTER_ASSISTANT_FAILED", { errcode: r.errcode, fromState: state });
    return "skip";
  }
  return "proceed";
}
async function kfCustomerBatchget(accessToken, externalUserId, fetchImpl = defaultFetch) {
  const j = await post("kf/customer/batchget", accessToken, { external_userid_list: [externalUserId] }, fetchImpl);
  if (j.errcode) {
    alert("security", "wecom", "KF_BATCHGET_FAILED", { errcode: j.errcode });
    return "";
  }
  const c = j.customer_list && j.customer_list[0];
  return c && c.unionid ? String(c.unionid) : "";
}

// rewrite/cloud/src/kit/throttle.ts
var COLL = COLLECTIONS.rateLimit;

// rewrite/cloud/src/kit/inspect.ts
var STUCK_PAID_MS = 72 * 3600 * 1e3;

// rewrite/cloud/src/kit/shipping.ts
var import_wx_server_sdk5 = __toESM(require("wx-server-sdk"), 1);

// rewrite/cloud/src/kit/contentsec.ts
var import_wx_server_sdk6 = __toESM(require("wx-server-sdk"), 1);
var RISKY = 87014;
var SCENE_COMMENT = 2;
function isRisky(code, suggest) {
  return code === RISKY || suggest === "risky";
}
function onInfraFail(infra, scene) {
  if (infra === "open") {
    alert("security", "msgSecCheck", "SEC_CHECK_INFRA", { scene });
    return { ok: true };
  }
  return { ok: false, error: "SEC_CHECK_FAIL" };
}
async function msgSecCheck(content, openid, scene = SCENE_COMMENT, infra = "closed") {
  const text = typeof content === "string" ? content.trim() : "";
  if (!text) return { ok: true };
  try {
    const r = await import_wx_server_sdk6.default.openapi.security.msgSecCheck({
      openid,
      content: text,
      version: 2,
      scene
    });
    const code = r && (r.errCode ?? r.errcode);
    const suggest = r && r.result && r.result.suggest;
    if (isRisky(code, suggest)) return { ok: false, error: "SEC_CHECK_FAIL" };
    if (code != null && code !== 0) return onInfraFail(infra, scene);
    return { ok: true };
  } catch (e) {
    const code = e && (e.errCode ?? e.errcode);
    if (code === RISKY) return { ok: false, error: "SEC_CHECK_FAIL" };
    return onInfraFail(infra, scene);
  }
}

// rewrite/cloud/src/kit/vod.ts
var SIGN_TTL_SEC = 6 * 3600;

// rewrite/cloud/src/kit/reconcile.ts
var CST = 8 * 36e5;

// rewrite/cloud/src/functions/cs/kfCallback/jev.ts
var JEV_URL = "https://api.typesafe.ai/v1/systemone";
var JEV_MODEL = "jev-latest";
function jevRequestBody(state) {
  return {
    model: JEV_MODEL,
    state,
    questions: {
      urgency: { type: "noul", instructions: "Does this convey urgency?" },
      department: {
        type: "choice",
        instructions: "Which team should handle this?",
        criteria: {
          billing: "Payments, invoicing, refunds",
          technical: "Bugs, outages, integrations",
          sales: "Pricing, upgrades, new accounts"
        }
      }
    }
  };
}
var DEPTS = ["billing", "technical", "sales"];
function parseJevBody(body) {
  const model = String(body && body.model || "");
  const urgency = Number(body && body.answers && body.answers.urgency && body.answers.urgency.noul);
  const department = String(
    body && body.answers && body.answers.department && body.answers.department.choice || ""
  );
  if (!model || !Number.isFinite(urgency) || !DEPTS.includes(department)) return null;
  return { model, urgency, department };
}
function mapJevDepartment(department) {
  if (department === "billing") return "aftersale";
  if (department === "technical") return "activation";
  if (department === "sales") return "tutorial";
  return null;
}
function jevHitWord(department) {
  if (department === "billing") return "\u552E\u540E";
  if (department === "technical") return "\u8BFE\u7A0B";
  if (department === "sales") return "\u6559\u7A0B";
  return "\u8BE5\u5206\u7C7B";
}
function envVersion() {
  return String(process.env.WX_ENV_VERSION || process.env.TCB_ENV_VERSION || "").toLowerCase();
}
async function loadJevGate(db2) {
  const ver = envVersion();
  if (ver === "release") return { on: false, key: "" };
  const envFlag = process.env.JEV_CS_ROUTE === "1";
  const trialish = ver === "develop" || ver === "trial";
  const envKey = String(process.env.TYPESAFE_API_KEY || "");
  const got = await db2.collection(COLLECTIONS.secureConfig).doc("typesafe").get().catch(() => null);
  const d = got && got.data || {};
  const dbFlag = String(d.JEV_CS_ROUTE || "") === "1";
  const dbKey = typeof d.TYPESAFE_API_KEY === "string" && d.TYPESAFE_API_KEY ? d.TYPESAFE_API_KEY : typeof d.apiKey === "string" ? d.apiKey : "";
  return { on: envFlag || trialish || dbFlag, key: envKey || dbKey };
}
async function askJev(state, apiKey, fetchFn) {
  const doFetch = fetchFn || globalThis.fetch;
  if (typeof doFetch !== "function" || !apiKey || !state) return null;
  const signal = typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function" ? AbortSignal.timeout(2500) : void 0;
  const res = await doFetch(JEV_URL, {
    method: "POST",
    headers: { Authorization: "Bearer " + apiKey, "Content-Type": "application/json" },
    body: JSON.stringify(jevRequestBody(state)),
    signal
  });
  if (!res || res.ok === false || typeof res.status === "number" && res.status >= 400) return null;
  return parseJevBody(await res.json());
}
function logJevEvidence(ev, mapped, extra) {
  console.info("[kf] jev", {
    model: ev.model,
    urgency: ev.urgency,
    department: ev.department,
    mapped,
    ...extra && extra.stateLen != null ? { stateLen: extra.stateLen } : {},
    ...extra && extra.skipped ? { skip: extra.skipped } : {}
  });
}
async function tryJevClassify(db2, text) {
  try {
    const gate = await loadJevGate(db2);
    if (!gate.on) return null;
    if (!gate.key) {
      console.info("[kf] jev", { skip: "no-key" });
      return null;
    }
    const ev = await askJev(text, gate.key);
    if (!ev) {
      console.info("[kf] jev", { skip: "fail-open" });
      return null;
    }
    return ev;
  } catch {
    console.info("[kf] jev", { skip: "fail-open" });
    return null;
  }
}

// rewrite/cloud/src/functions/cs/kfCallback/dispatch.ts
async function firstSeen(db2, msgid) {
  try {
    await db2.collection(COLLECTIONS.kfState).add({ data: { _id: "seen:" + msgid, at: Date.now() } });
    return "first";
  } catch {
    const got = await db2.collection(COLLECTIONS.kfState).doc("seen:" + msgid).get().catch(() => null);
    return got && got.data ? "duplicate" : "error";
  }
}
async function processKfBatch(db2, msgs, handleOne) {
  let anyFailed = false;
  for (const msg of msgs || []) {
    const msgid = String(msg && msg.msgid || "");
    if (msgid) {
      const claim = await firstSeen(db2, msgid);
      if (claim === "duplicate") continue;
      if (claim === "error") {
        console.error("[kf] claim failed (infra)", { msgid });
        alert("security", "kfCallback", "CLAIM_FAILED", {});
        anyFailed = true;
        continue;
      }
    }
    try {
      await handleOne(msg);
    } catch (e) {
      console.error("[kf] handle threw", { msgid }, String(e));
      alert("security", "kfCallback", "HANDLE_FAILED", {});
      if (msgid)
        await db2.collection(COLLECTIONS.kfState).doc("seen:" + msgid).remove().catch(() => {
        });
      anyFailed = true;
    }
  }
  return anyFailed;
}
var KEYWORDS = [
  { cat: "logistics", words: ["\u7269\u6D41", "\u5FEB\u9012", "\u53D1\u8D27", "\u6CA1\u5230", "\u5230\u8D27", "\u8FD0\u5355", "\u5355\u53F7", "\u6536\u8D27"] },
  { cat: "activation", words: ["\u6FC0\u6D3B\u7801", "\u6FC0\u6D3B", "\u8BFE\u7A0B", "\u89C6\u9891", "\u5151\u6362", "\u89C2\u770B", "\u770B\u4E0D\u4E86"] },
  {
    cat: "aftersale",
    words: ["\u9000\u6B3E", "\u9000\u8D27", "\u6362\u8D27", "\u552E\u540E", "\u6F0F\u53D1", "\u574F\u4E86", "\u5C11\u4E86", "\u8D28\u91CF", "\u9000", "\u6362"]
  },
  { cat: "tutorial", words: ["\u6559\u7A0B", "\u94A9\u7EC7", "\u9488\u6CD5", "\u56FE\u89E3", "\u600E\u4E48\u94A9", "\u6559\u5B66"] }
];
function recognize(text) {
  const t = String(text || "");
  for (const g of KEYWORDS) {
    const hit = g.words.find((w) => t.includes(w));
    if (hit) return { cat: g.cat, word: hit };
  }
  return null;
}
function extUserId(msg) {
  return String(msg && (msg.external_userid || msg.event && msg.event.external_userid) || "");
}
function menu(head, items, tail = "\u6216\u76F4\u63A5\u6253\u5B57\u544A\u8BC9\u6211\uFF5E") {
  return {
    head_content: head,
    list: items.map((it) => ({
      type: "click",
      click: { id: it.id, content: it.content }
    })),
    tail_content: tail
  };
}
function rootMenu() {
  return menu("\u60F3\u54A8\u8BE2\u4EC0\u4E48\uFF1F\u70B9\u4E00\u4E0B\u5FEB\u901F\u5B9A\u4F4D \u{1F447}", [
    { id: "cat:logistics", content: "\u{1F4E6} \u6211\u7684\u8BA2\u5355 / \u7269\u6D41" },
    { id: "cat:activation", content: "\u{1F3AC} \u6FC0\u6D3B\u7801 / \u8BFE\u7A0B / \u89C6\u9891" },
    { id: "cat:aftersale", content: "\u{1F504} \u9000\u6362\u8D27 / \u552E\u540E" },
    { id: "cat:tutorial", content: "\u{1F9F6} \u94A9\u7EC7\u6559\u7A0B" },
    { id: "csat", content: "\u2B50 \u8BC4\u4EF7\u670D\u52A1" },
    { id: "human", content: "\u{1F64B} \u5176\u5B83 / \u627E\u4EBA\u5DE5" }
  ]);
}
function rateMenu() {
  return menu(
    "\u7ED9\u672C\u6B21\u670D\u52A1\u6253\u4E2A\u5206\u5427\uFF08\u70B9\u4E00\u4E0B\uFF09\u{1F447}",
    [
      { id: "rate:5", content: "\u2B50\u2B50\u2B50\u2B50\u2B50 \u975E\u5E38\u6EE1\u610F" },
      { id: "rate:4", content: "\u2B50\u2B50\u2B50\u2B50 \u6EE1\u610F" },
      { id: "rate:3", content: "\u2B50\u2B50\u2B50 \u4E00\u822C" },
      { id: "rate:2", content: "\u2B50\u2B50 \u4E0D\u592A\u6EE1\u610F" },
      { id: "rate:1", content: "\u2B50 \u5F88\u4E0D\u6EE1\u610F" }
    ],
    "\u70B9\u661F\u661F\u5373\u53EF\uFF0C\u611F\u8C22\u4F60\u7684\u53CD\u9988\uFF5E"
  );
}
var CSAT_REASONS = {
  resolved: "\u95EE\u9898\u5DF2\u89E3\u51B3",
  unresolved: "\u95EE\u9898\u6CA1\u89E3\u51B3",
  slow: "\u56DE\u590D\u6709\u70B9\u6162",
  attitude: "\u6001\u5EA6\u5F88\u597D",
  none: ""
};
function csatReasonMenu() {
  return menu(
    "\u60F3\u8865\u5145\u70B9\u4EC0\u4E48\u5417\uFF1F\uFF08\u53EF\u9009\uFF09",
    [
      { id: "csatnote:resolved", content: "\u95EE\u9898\u5DF2\u89E3\u51B3" },
      { id: "csatnote:unresolved", content: "\u95EE\u9898\u6CA1\u89E3\u51B3" },
      { id: "csatnote:slow", content: "\u56DE\u590D\u6709\u70B9\u6162" },
      { id: "csatnote:attitude", content: "\u6001\u5EA6\u5F88\u597D" },
      { id: "csatnote:none", content: "\u4E0D\u8865\u5145\u4E86" }
    ],
    "\u70B9\u4E00\u4E0B\u5C31\u597D\uFF0C\u4E0D\u8865\u5145\u4E5F\u6CA1\u5173\u7CFB\uFF5E"
  );
}
function parseRate(menuId) {
  const m = /^rate:([1-5])$/.exec(String(menuId || ""));
  return m ? Number(m[1]) : null;
}
function menuFor(cat, word) {
  if (cat === "logistics")
    return menu(`\u770B\u4F60\u5728\u95EE\u300C${word}\u300D\u76F8\u5173 \u{1F447}`, [
      { id: "order:query", content: "\u67E5\u6211\u7684\u8BA2\u5355 / \u7269\u6D41" },
      { id: "logistics:eta", content: "\u591A\u4E45\u53D1\u8D27" },
      { id: "addr:change", content: "\u6539\u6536\u8D27\u5730\u5740" },
      { id: "human", content: "\u8F6C\u4EBA\u5DE5" }
    ]);
  if (cat === "activation")
    return menu(`\u770B\u4F60\u5728\u95EE\u300C${word}\u300D\u76F8\u5173 \u{1F447}`, [
      { id: "activation:howto", content: "\u6FC0\u6D3B\u7801\u600E\u4E48\u7528" },
      { id: "course:open", content: "\u53BB\u770B\u6211\u7684\u8BFE\u7A0B" },
      { id: "human", content: "\u8F6C\u4EBA\u5DE5" }
    ]);
  if (cat === "aftersale")
    return menu(`\u770B\u4F60\u5728\u95EE\u300C${word}\u300D\u76F8\u5173 \u{1F447}`, [
      { id: "aftersale:policy", content: "\u9000\u6362\u653F\u7B56" },
      { id: "aftersale:apply", content: "\u53BB\u7533\u8BF7\u552E\u540E" },
      { id: "human", content: "\u8F6C\u4EBA\u5DE5\uFF08\u627F\u8BFA/\u7EA0\u7EB7\uFF09" }
    ]);
  return menu(`\u770B\u4F60\u5728\u95EE\u300C${word}\u300D\u76F8\u5173 \u{1F447}`, [
    { id: "course:open", content: "\u53BB\u770B\u6559\u7A0B / \u8BFE\u7A0B" },
    { id: "human", content: "\u8F6C\u4EBA\u5DE5" }
  ]);
}
function route(menuId) {
  if (menuId === "human") return { type: "transfer" };
  if (menuId === "order:query") return { type: "order_query" };
  if (menuId === "aftersale:apply")
    return {
      type: "miniprogram",
      // 新线 app.json 注册路由（课程链路审计 2026-07-17·kf-card-page-registered 守卫已扩新线面锁此处）：
      // 原 'pages/aftersales/index' 是旧线 uni-app 路径记法，新线原生小程序注册的是 目录/同名文件
      page: "pages/aftersales/aftersales",
      title: "\u7533\u8BF7\u552E\u540E",
      fallbackText: "\u7533\u8BF7\u552E\u540E\u8BF7\u5728\u5C0F\u7A0B\u5E8F\u300C\u6211\u7684 \u2192 \u8BA2\u5355 \u2192 \u7533\u8BF7\u552E\u540E\u300D\u64CD\u4F5C\u3002\u9700\u8981\u6211\u534F\u52A9\u53EF\u70B9\u300C\u8F6C\u4EBA\u5DE5\u300D\u3002"
    };
  if (menuId === "course:open")
    return {
      type: "miniprogram",
      // 原 'pkg-video/courses/index' 是旧线分包规划路径，新线无分包、课程列表页为 my-courses（守卫锁同上）
      page: "pages/my-courses/my-courses",
      title: "\u6211\u7684\u8BFE\u7A0B",
      fallbackText: "\u5728\u5C0F\u7A0B\u5E8F\u300C\u6211\u7684 \u2192 \u8BFE\u7A0B\u300D\u5373\u53EF\u89C2\u770B\u5DF2\u6FC0\u6D3B\u7684\u8BFE\u7A0B\u3002\u6FC0\u6D3B\u7801\u76F8\u5173\u70B9\u4E0A\u65B9\u83DC\u5355\uFF0C\u6216\u70B9\u300C\u8F6C\u4EBA\u5DE5\u300D\u3002"
    };
  if (menuId.startsWith("cat:")) {
    const cat = menuId.slice(4);
    return { type: "menu", content: menuFor(cat, "\u8BE5\u5206\u7C7B") };
  }
  if (menuId === "csat") return { type: "menu", content: rateMenu() };
  const score = parseRate(menuId);
  if (score) return { type: "csat", score };
  if (menuId.startsWith("csatnote:")) {
    const tag = menuId.slice("csatnote:".length);
    return { type: "csat_note", note: CSAT_REASONS[tag] ?? "" };
  }
  if (menuId.includes(":")) return { type: "faq", faqKey: menuId };
  return { type: "menu", content: rootMenu() };
}
async function faqAnswer(db2, faqKey) {
  if (!faqKey) return null;
  const got = await db2.collection(COLLECTIONS.kb).doc(faqKey).get().catch(() => null);
  const d = got && got.data;
  if (!d || d.enabled === false) return null;
  return d.answer ? String(d.answer) : null;
}
async function recordCsat(db2, input) {
  const score = Number(input.score);
  if (!(score >= 1 && score <= 5)) return null;
  const euid = String(input.externalUserId || "");
  if (!euid) return null;
  const createdAt = Date.now();
  const id = "csat:" + euid + ":" + createdAt;
  let wrote = true;
  await db2.collection(COLLECTIONS.csat).doc(id).set({
    data: {
      externalUserId: euid,
      openid: input.openid || null,
      score,
      note: String(input.note || "").slice(0, 200),
      createdAt
    }
  }).catch(() => {
    wrote = false;
  });
  if (!wrote) {
    alert("anomaly", "recordCsat", "CSAT_WRITE_FAIL", { euid });
    return null;
  }
  await db2.collection(COLLECTIONS.kfState).doc("csatlast:" + euid).set({ data: { csatId: id, at: createdAt } }).catch(() => {
    alert("anomaly", "recordCsat", "CSAT_POINTER_FAIL", { euid });
  });
  return id;
}
async function attachCsatNote(db2, externalUserId, note) {
  const euid = String(externalUserId || "");
  if (!euid || !note) return;
  const got = await db2.collection(COLLECTIONS.kfState).doc("csatlast:" + euid).get().catch(() => null);
  const csatId = got && got.data && got.data.csatId;
  if (!csatId) return;
  await db2.collection(COLLECTIONS.csat).doc(csatId).update({ data: { note: String(note).slice(0, 200) } }).catch(() => {
  });
  await db2.collection(COLLECTIONS.kfState).doc("csatlast:" + euid).remove().catch(() => {
  });
}
async function resolveOpenid(db2, externalUserId) {
  if (!externalUserId) return null;
  const got = await db2.collection(COLLECTIONS.kfIdentity).doc("ext:" + externalUserId).get().catch(() => null);
  return got && got.data && got.data.openid ? String(got.data.openid) : null;
}
async function summarizeOrders(db2, openid) {
  const r = await db2.collection(COLLECTIONS.orders).where({ _openid: openid }).orderBy("createdAt", "desc").limit(3).get().catch(() => ({ data: [] }));
  const list = r && r.data || [];
  if (!list.length) return "\u6CA1\u67E5\u5230\u4F60\u540D\u4E0B\u7684\u8BA2\u5355\u3002\u5982\u679C\u521A\u4E0B\u5355\u53EF\u7A0D\u540E\u518D\u8BD5\uFF0C\u6216\u70B9\u300C\u8F6C\u4EBA\u5DE5\u300D\u3002";
  const STAT = { pending: "\u5F85\u652F\u4ED8", paid: "\u5DF2\u652F\u4ED8/\u5F85\u53D1\u8D27", shipped: "\u5DF2\u53D1\u8D27", refund_required: "\u5F85\u9000\u6B3E", payment_exception: "\u652F\u4ED8\u5F02\u5E38\u5F85\u5904\u7406", done: "\u5DF2\u5B8C\u6210", closed: "\u5DF2\u5173\u95ED" };
  const lines = list.map((o) => {
    const tracking = o.shipping && o.shipping.trackingNo;
    return `\xB7 \u8BA2\u5355 ${o.id || o._id}\uFF1A${STAT[o.status] || o.status}${tracking ? "\uFF08\u8FD0\u5355 " + tracking + "\uFF09" : ""}`;
  });
  return "\u4F60\u6700\u8FD1\u7684\u8BA2\u5355\uFF1A\n" + lines.join("\n") + "\n\u9700\u8981\u66F4\u591A\u5E2E\u52A9\u70B9\u300C\u8F6C\u4EBA\u5DE5\u300D\u3002";
}
async function enqueueSession(db2, openKfId, externalUserId) {
  const euid = String(externalUserId || "");
  if (!euid || !openKfId) return "failed";
  const now = Date.now();
  const id = "wxkf:" + openKfId + ":" + euid;
  let queued = false;
  try {
    await db2.collection(COLLECTIONS.csSession).add({
      data: {
        _id: id,
        status: "pending",
        externalUserId: euid,
        openKfId,
        createdAt: now,
        updatedAt: now
      }
    });
    queued = true;
  } catch {
    const got = await db2.collection(COLLECTIONS.csSession).doc(id).get().catch(() => null);
    if (!got || !got.data) {
      console.error("[kf] enqueue failed (infra)", { id });
      alert("security", "kfCallback", "ENQUEUE_FAILED", {});
      return "failed";
    }
    const _ = db2.command;
    const r = await transition("csSession", id, ["closed"], "pending", {
      agentId: null,
      claimedAt: null,
      createdAt: now,
      updatedAt: now,
      qc: _.remove(),
      qcSampledAt: _.remove()
    }).catch(() => ({ moved: false }));
    queued = !!(r && r.moved);
  }
  if (queued) await notifyOnlineAgents(db2, id);
  return queued ? "queued" : "already";
}
async function notifyOnlineAgents(db2, sessionId) {
  try {
    const st = await db2.collection(COLLECTIONS.agentState).where({ status: "online" }).get().catch(() => ({ data: [] }));
    const ids = (st.data || []).map((a) => a._id).filter(Boolean);
    if (!ids.length) return;
    const touser = [];
    for (const id of ids) {
      const docId = id === "admin" ? "auth" : id;
      const g = await db2.collection("adminConfig").doc(docId).get().catch(() => null);
      const uid = g && g.data && g.data.wecomUserId;
      if (uid) touser.push(String(uid));
    }
    await sendAgentCard(db2, touser, {
      title: "\u65B0\u4F1A\u8BDD\u5F85\u63A5",
      description: "\u6709\u987E\u5BA2\u8F6C\u5165\u4EBA\u5DE5\u5BA2\u670D\uFF0C\u8BF7\u53CA\u65F6\u5230\u5DE5\u4F5C\u53F0\u63A5\u5F85\u3002",
      url: AGENT_DESK_URL + "?session=" + sessionId
    });
  } catch {
  }
}
var base = (touser, openKfId) => ({ touser, open_kfid: openKfId });
var buildText = (touser, openKfId, content) => ({
  ...base(touser, openKfId),
  msgtype: "text",
  text: { content }
});
var buildMsgMenu = (touser, openKfId, content) => ({
  ...base(touser, openKfId),
  msgtype: "msgmenu",
  msgmenu: content
});
var buildMiniprogram = (touser, openKfId, cfg, page, title) => ({
  ...base(touser, openKfId),
  msgtype: "miniprogram",
  miniprogram: { appid: cfg.appid, title, thumb_media_id: cfg.thumbMediaId, pagepath: page }
});
async function heldStatus(db2, openKfId, externalUserId) {
  const held = await db2.collection(COLLECTIONS.csSession).doc("wxkf:" + openKfId + ":" + externalUserId).get().catch(() => null);
  const hs = held && held.data && held.data.status;
  return hs === "pending" || hs === "active" || hs === "escalated" ? hs : null;
}
var CSAT_ASK_TTL_MS = 48 * 36e5;
async function handleMessage(ctx, incoming) {
  const { db: db2, openKfId, cfg, send } = ctx;
  const to = incoming.externalUserId;
  const hs = await heldStatus(db2, openKfId, to);
  if (hs === "pending" || hs === "active" || hs === "escalated") {
    if (incoming.menuId && route(incoming.menuId).type === "transfer") {
      await send(
        buildText(
          to,
          openKfId,
          hs === "active" ? "\u4EBA\u5DE5\u5BA2\u670D\u6B63\u5728\u4E3A\u4F60\u670D\u52A1\u4E2D\uFF5E\u76F4\u63A5\u7559\u8A00\u5373\u53EF\uFF0C\u5BA2\u670D\u90FD\u80FD\u770B\u5230 \u{1F64C}" : "\u4F60\u5DF2\u5728\u4EBA\u5DE5\u961F\u5217\u4E2D\uFF0C\u5BA2\u670D\u4F1A\u5C3D\u5FEB\u63A5\u5165\uFF5E\u6709\u8865\u5145\u53EF\u4EE5\u76F4\u63A5\u7559\u8A00\uFF0C\u63A5\u5165\u540E\u90FD\u80FD\u770B\u5230 \u{1F64C}"
        )
      );
    }
    return;
  }
  if (!incoming.menuId) {
    const m = /^\s*([1-5])\s*$/.exec(incoming.text);
    if (m) {
      const ask = await db2.collection(COLLECTIONS.kfState).doc("csatask:" + to).get().catch(() => null);
      const askAt = ask && ask.data && Number(ask.data.at);
      if (askAt && Date.now() - askAt < CSAT_ASK_TTL_MS) {
        await db2.collection(COLLECTIONS.kfState).doc("csatask:" + to).remove().catch(() => {
        });
        const openid = await resolveOpenid(db2, to);
        await recordCsat(db2, { externalUserId: to, openid, score: Number(m[1]) });
        await send(buildMsgMenu(to, openKfId, csatReasonMenu()));
        return;
      }
    }
  }
  const r = incoming.menuId ? route(incoming.menuId) : await (async () => {
    const hit = recognize(incoming.text);
    const ev = await tryJevClassify(db2, incoming.text);
    if (ev) {
      const cat = mapJevDepartment(ev.department);
      logJevEvidence(ev, cat || (hit ? hit.cat : null), { stateLen: String(incoming.text || "").length });
      if (!hit && cat) return { type: "menu", content: menuFor(cat, jevHitWord(ev.department)) };
    }
    return hit ? { type: "menu", content: menuFor(hit.cat, hit.word) } : { type: "menu", content: rootMenu() };
  })();
  switch (r.type) {
    case "transfer": {
      const q = await enqueueSession(db2, openKfId, to);
      await send(
        buildText(
          to,
          openKfId,
          q === "failed" ? "\u8F6C\u63A5\u4EBA\u5DE5\u65F6\u9047\u5230\u70B9\u95EE\u9898\uFF0C\u8BF7\u7A0D\u540E\u518D\u70B9\u4E00\u6B21\u300C\u627E\u4EBA\u5DE5\u300D\u{1F64F} \u4E5F\u53EF\u4EE5\u5148\u628A\u95EE\u9898\u63CF\u8FF0\u5728\u8FD9\u91CC\u3002" : "\u5DF2\u4E3A\u4F60\u8F6C\u63A5\u4EBA\u5DE5\u5BA2\u670D\uFF5E\u5DE5\u4F5C\u4EBA\u5458\u4F1A\u5C3D\u5FEB\u5728\u8FD9\u91CC\u56DE\u590D\u4F60\u3002\u4F60\u4E5F\u53EF\u4EE5\u5148\u628A\u95EE\u9898\u63CF\u8FF0\u6E05\u695A\uFF0C\u65B9\u4FBF\u66F4\u5FEB\u5904\u7406 \u{1F647}"
        )
      );
      return;
    }
    case "faq": {
      const ans = await faqAnswer(db2, r.faqKey);
      if (ans) await send(buildText(to, openKfId, ans));
      else await send(buildMsgMenu(to, openKfId, rootMenu()));
      return;
    }
    case "menu":
      await send(buildMsgMenu(to, openKfId, r.content));
      return;
    case "miniprogram":
      if (cfg.appid && cfg.thumbMediaId)
        await send(buildMiniprogram(to, openKfId, cfg, r.page, r.title));
      else await send(buildText(to, openKfId, r.fallbackText));
      return;
    case "order_query": {
      const openid = await resolveOpenid(db2, to);
      if (!openid) {
        await send(
          buildText(
            to,
            openKfId,
            "\u8FD8\u6CA1\u8BC6\u522B\u5230\u4F60\u7684\u5C0F\u7A0B\u5E8F\u8D26\u53F7\uFF5E\u8BF7\u5148\u5728\u5C0F\u7A0B\u5E8F\u91CC\u767B\u5F55\u4E00\u6B21\uFF0C\u4E4B\u540E\u6211\u5C31\u80FD\u5728\u8FD9\u91CC\u5E2E\u4F60\u67E5\u8BA2\u5355\u3002\u4E5F\u53EF\u70B9\u300C\u8F6C\u4EBA\u5DE5\u300D\u3002"
          )
        );
        return;
      }
      await send(buildText(to, openKfId, await summarizeOrders(db2, openid)));
      return;
    }
    case "csat": {
      const openid = await resolveOpenid(db2, to);
      await recordCsat(db2, { externalUserId: to, openid, score: r.score });
      await send(buildMsgMenu(to, openKfId, csatReasonMenu()));
      return;
    }
    case "csat_note": {
      if (r.note) await attachCsatNote(db2, to, r.note);
      else
        await db2.collection(COLLECTIONS.kfState).doc("csatlast:" + to).remove().catch(() => {
        });
      await send(buildText(to, openKfId, "\u8C22\u8C22\u4F60\u7684\u53CD\u9988\uFF0C\u6211\u4EEC\u4F1A\u7EE7\u7EED\u6539\u8FDB \u{1F64F}"));
      return;
    }
  }
}

// rewrite/cloud/src/functions/cs/kfCallback/archive.ts
var CHANNEL_WXKF = "wxkf";
function msgEuid(msg) {
  return String(msg && (msg.external_userid || msg.event && msg.event.external_userid) || "");
}
async function resolveOpenidBestEffort(db2, euid) {
  if (!euid) return "";
  const got = await db2.collection(COLLECTIONS.kfIdentity).doc("ext:" + euid).get().catch(() => null);
  return got && got.data && got.data.openid ? String(got.data.openid) : "";
}
function incomingText(msg) {
  if (msg && msg.msgtype === "text") return String(msg.text && msg.text.content || "");
  return "[" + String(msg && msg.msgtype || "unknown") + "]";
}
function msgMediaId(msg) {
  return String(msg && msg.msgtype === "image" && msg.image && msg.image.media_id || "");
}
function payloadText(payload) {
  if (!payload) return "";
  if (payload.msgtype === "text") return String(payload.text && payload.text.content || "");
  if (payload.msgtype === "msgmenu") {
    const m = payload.msgmenu || {};
    const items = (Array.isArray(m.list) ? m.list : []).map((it) => it && it.click && it.click.content || "").filter(Boolean);
    return [String(m.head_content || ""), ...items].filter(Boolean).join(" / ");
  }
  if (payload.msgtype === "miniprogram")
    return "[\u5C0F\u7A0B\u5E8F\u5361\u7247] " + String(payload.miniprogram && payload.miniprogram.title || "");
  return "[" + String(payload.msgtype || "unknown") + "]";
}
async function archiveInbound(db2, msg, openKfId) {
  try {
    const msgid = String(msg && msg.msgid || "");
    if (!msgid) return;
    if (String(msg && msg.msgtype || "") === "event") return;
    const euid = msgEuid(msg);
    const openid = await resolveOpenidBestEffort(db2, euid);
    await db2.collection(COLLECTIONS.conversations).add({
      data: {
        _id: "wxkf:in:" + msgid,
        channel: CHANNEL_WXKF,
        direction: "in",
        openKfId: String(openKfId || ""),
        externalUserId: euid,
        openid,
        msgtype: String(msg && msg.msgtype || ""),
        text: incomingText(msg),
        mediaId: msgMediaId(msg),
        // B5：image 消息落 media_id（非 image 为''）·getMediaUrl 据此下载
        // at＝统一「入库时刻」（毫秒·与出站 archiveOutbound/sendAgentMessage 同轴），游标按单调递增不丢晚到消息。
        at: Date.now()
      }
    });
  } catch {
  }
}
async function archiveOutbound(db2, payload, openKfId) {
  try {
    const euid = String(payload && payload.touser || "");
    const openid = await resolveOpenidBestEffort(db2, euid);
    await db2.collection(COLLECTIONS.conversations).add({
      data: {
        channel: CHANNEL_WXKF,
        direction: "out",
        openKfId: String(openKfId || ""),
        externalUserId: euid,
        openid,
        msgtype: String(payload && payload.msgtype || ""),
        text: payloadText(payload),
        at: Date.now()
      }
    });
  } catch {
  }
}

// rewrite/cloud/src/functions/cs/kfCallback/index.ts
var db = getDb();
var wxkfCfg = () => getSecureConfigFields(db, "wxkf", ["corpId", "secret", "miniappAppId", "thumbMediaId"]);
async function ensureKfIdentity(db2, token, euid) {
  try {
    if (!euid) return;
    const got = await db2.collection(COLLECTIONS.kfIdentity).doc("ext:" + euid).get().catch(() => null);
    if (got && got.data && got.data.openid) return;
    const unionid = await kfCustomerBatchget(token, euid);
    if (!unionid) return;
    const u = await db2.collection("users").where({ unionid }).limit(1).get().catch(() => ({ data: [] }));
    const openid = u.data && u.data[0] && u.data[0]._openid;
    if (!openid) return;
    await db2.collection(COLLECTIONS.kfIdentity).doc("ext:" + euid).set({ data: { openid, unionid, updatedAt: Date.now() } });
  } catch {
  }
}
function normalize(msg) {
  const externalUserId = extUserId(msg);
  if (!externalUserId) return null;
  if (msg.msgtype === "text") {
    return { externalUserId, menuId: String(msg.text?.menu_id || ""), text: String(msg.text?.content || "") };
  }
  return null;
}
var main = defineKfCallback({
  // 单次合并读注入三凭证（corpid：企业内部单 corp——解密 receiveId 须等于它，拒跨 corp 伪造·审计 P1）
  creds: async () => {
    const f = await getSecureConfigFields(db, "wxkf", ["token", "aesKey", "corpId"]);
    return { token: f.token, aesKey: f.aesKey, corpid: f.corpId };
  },
  onEvent: async ({ syncToken, openKfId }) => {
    const f = await wxkfCfg();
    let token;
    try {
      token = await getAccessToken({ corpid: f.corpId, secret: f.secret });
    } catch (e) {
      console.error("[kf] getAccessToken threw", String(e));
      return;
    }
    const send = async (payload) => {
      const res = await sendMsg(token, payload);
      if (res && res.errcode) alert("security", "kfCallback", "SENDMSG_FAILED", { errcode: res.errcode, msgtype: payload?.msgtype });
      else await archiveOutbound(db, payload, openKfId);
      return res;
    };
    const ctx = { db, openKfId, cfg: { appid: f.miniappAppId, thumbMediaId: f.thumbMediaId }, send };
    const cursorId = "cursor:" + openKfId;
    let cursor = "";
    const cur = await db.collection(COLLECTIONS.kfState).doc(cursorId).get().catch(() => null);
    if (cur && cur.data && typeof cur.data.cursor === "string") cursor = cur.data.cursor;
    const handleOne = async (msg) => {
      const euid = extUserId(msg);
      if (msg.msgtype === "text" && !(msg.text && msg.text.menu_id)) {
        const openid = await resolveOpenid(db, euid) || "";
        if (openid) {
          const sec = await msgSecCheck(String(msg.text && msg.text.content || ""), openid, SCENE_COMMENT, "open");
          if (!sec.ok) {
            if (euid)
              await send({
                touser: euid,
                open_kfid: openKfId,
                msgtype: "text",
                text: { content: "\u8FD9\u6761\u6D88\u606F\u672A\u80FD\u53D1\u9001\uFF0C\u8BF7\u6362\u4E2A\u8BF4\u6CD5\u518D\u8BD5" }
              });
            return;
          }
        }
      }
      await archiveInbound(db, msg, openKfId);
      if (euid) {
        const gate = await ensureSmartAssistant(token, { openKfId, externalUserId: euid });
        if (gate === "skip") {
          await ensureKfIdentity(db, token, euid);
          return;
        }
      }
      if (msg.msgtype === "event" && msg.event?.event_type === "enter_session") {
        if (!(euid && await heldStatus(db, openKfId, euid)))
          await send(buildMsgMenu(euid, openKfId, rootMenu()));
      } else {
        const incoming = normalize(msg);
        if (incoming) await handleMessage(ctx, incoming);
      }
      await ensureKfIdentity(db, token, euid);
    };
    const KF_BATCH_LIMIT = 50;
    const KF_TIME_BUDGET_MS = 15e3;
    const startedAt = Date.now();
    for (let guard = 0; guard < 20; guard++) {
      if (Date.now() - startedAt > KF_TIME_BUDGET_MS) {
        break;
      }
      const r = await syncMsg(token, { cursor, token: syncToken, openKfId, limit: KF_BATCH_LIMIT });
      if (r.errcode) {
        alert("security", "kfCallback", "SYNCMSG_FAILED", { errcode: r.errcode });
        break;
      }
      const anyFailed = await processKfBatch(db, r.msg_list, handleOne);
      if (anyFailed) {
        break;
      }
      cursor = r.next_cursor || cursor;
      await db.collection(COLLECTIONS.kfState).doc(cursorId).set({ data: { cursor, updatedAt: Date.now() } }).catch(() => {
      });
      if (!r.has_more) break;
    }
  }
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
